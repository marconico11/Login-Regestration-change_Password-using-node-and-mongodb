var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});
router.get('/reg', function(req, res, next) {
  res.render('reg');
});
router.get('/login', function(req, res, next) {
  res.render('login');
});

router.get('/Profile', function(req, res, next) {
  res.render('hello');
});
router.get('/fpassword', function(req, res, next) {
  res.render('fpassword');
});

module.exports = router;
