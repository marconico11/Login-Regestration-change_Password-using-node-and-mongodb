var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
// New Code
var mongoose = require('mongoose');
var bcrypt = require('bcryptjs');
var randomstring = require("randomstring");
var nodemailer = require('nodemailer');
//for mongo
var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
var ObjectId = require('mongodb').ObjectID;
var url = 'mongodb://127.0.0.1:12346/new';

//global var
var loggedUser;

//creating a path for rouths
var routes = require('./routes/index');
var users = require('./routes/users');
//ini app
var app = express();

//view engins
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');



// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));

// middle wares
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', routes);
app.use('/users', users);


//connect to local mongodb database
var db = mongoose.connect('mongodb://127.0.0.1:12346/new');
var logger = require('./database/data.js');
//testing if connection was a success.
mongoose.connection.once('connected', function() {
    console.log("Connected to database");
});







//forgot password
app.post('/fpassword', function(req, res) {
    var query = {};
    query['Email'] = req.body.email;
    console.log(req.body.email);
    logger.findOne(query, function(err, docs) {
        if (err) res.json(err);
        else if (docs != null) {
            console.log(docs.Email);
            var newpassword = randomstring.generate({
                length: 12,
                charset: 'alphabetic'
            });



            var mailOptions = {
                from: 'spartian.sen738@gmail.com>', // sender address
                to: docs.Email, // list of receivers
                subject: 'Change password Request', // Subject line
                html: '<b>Your new password is <%=newpassword%> </b>'
                    //, // plaintext body
                    // html: '<b>Hello world ✔</b>' // You can choose to send an HTML body instead
            };


            var transporter = nodemailer.createTransport({
                service: 'gmail',
                auth: {
                    user: "",
                    pass: "" // Your email id
                }
            });
            //}
            transporter.sendMail(mailOptions, function(error, info) {
                if (error) {
                    console.log(error);
                    res.json(error);
                } else {
                    console.log('Message sent: ' + info.response);
                    res.json(info.response);
                };
            });
            var msg = "Your new password has been send to your mail";
            res.render('relogin', { msg: msg });
        } else {
            console.log('user not found');
            var msg = "User not found, Please Sign Up or Enter the required fields";
            res.render('rereg', { msg: msg });
        }

    });

});


//updating password
app.post('/rpassword', function(req, res) { // Control from userDetails
    var query = {};

    query['Email'] = req.body.email;
    if (req.body.email != null) {
        logger.findOne(query, function(err, docs) {
            var hash = bcrypt.hashSync(req.body.newpass, docs.salt);

            if (err) res.json(err);
            else if (docs != null) {
                console.log(docs);
                var updatedatabase = function(db, callback) {
                    db.collection('loggers').update({ "Email": req.body.email }, { $set: { "Password": hash } },
                        function(err, results) {
                            console.log(err);
                            callback();
                        });
                };

                MongoClient.connect(url, function(err, db) {
                    assert.equal(null, err);

                    updatedatabase(db, function() {
                        db.close();
                    });
                });

                var msg = "Password Updated";
                res.render('relogin', { msg: msg });
            }




        });
    } else {
        console.log('user not found');
        var msg = "User not found, Kindly Register to Log in";
        res.render('rereg', { msg: msg });
    }

});







// Action from userDetails
app.post('/createUser', function(req, res) { // Control from userDetails
    if (req.body.user_name != null) {
        //encryption
        var salt = bcrypt.genSaltSync(10);
        var hash = bcrypt.hashSync(req.body.user_password, salt);
        new logger({
            UserName: req.body.user_name,
            Email: req.body.user_email,
            Password: hash, //req.body.user_password,
            Role: req.body.user_job,
            Bio: req.body.user_bio,
            Interests: req.body.user_interest,
            Salt: salt
        }).save(function(err, doc) {
            if (err) res.json(err);
            else {

                res.render('login');
            }
        });
    } else {
        console.log("Testing");
    }
});

//file upload
var multer = require('multer');
var storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, './uploads/')
    },
    filename: function(req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now())
    }
});

var upload = multer({ storage: storage }).single('pic');
app.post('/upload', function(request, response) {

    val = require("./app.js");
    logger.findOne(val.loggedUser, function(err, docs) {
        if (err) res.json(err);
        else if (docs != null) {
            upload(request, response, function(err) {
                if (err) {
                    console.log('Error Occured');
                    return;
                }
                console.log(request.file.path);
                response.end('Your File Uploaded');
                var updatedatabase = function(db, callback) {
                    console.log(val.loggedUser);
                    db.collection('loggers').update({ "UserName": val.loggedUser }, { $set: { "Image": request.file.path } },

                        function(err, results) {
                            callback();
                        });
                };

                MongoClient.connect(url, function(err, db) {
                    assert.equal(null, err);

                    updatedatabase(db, function() {
                        db.close();
                    });
                });

            })



        }




    });




});






//value fetch
app.post('/loginuser', function(req, res) { ///display to /normalUser
    var query = {};
    var details = {};


    query['UserName'] = req.body.user_name;
    if (req.body.user_name != null) {

        logger.findOne(query, function(err, docs) {
            var hash = bcrypt.hashSync(req.body.user_password, docs.Salt);
            console.log(docs.Password);
            console.log(hash);
            if (err) res.json(err);
            else if (docs != null) {
                if (hash === docs.Password) {
                    loggedUser = req.body.user_name;
                    module.exports.loggedUser = loggedUser;
                    res.render('hello', { details: docs, user: loggedUser });
                } else {
                    var msg = "Incorrect password, try again";
                    res.render('relogin', { msg: msg });
                }

            } else {
                console.log('user not found');
                var msg = "User not found, Please Sign Up";
                res.render('rereg', { msg: msg });
            }

        });
    }
});


















// catch 404 and forward to error handler
app.use(function(req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
    app.use(function(err, req, res, next) {
        res.status(err.status || 500);
        res.render('error', {
            message: err.message,
            error: err
        });
    });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
        message: err.message,
        error: {}
    });
});


module.exports = app;
