var randomstring = require("randomstring");




var newpass =randomstring.generate({
  length: 12,
  charset: 'alphabetic'
});
console.log(newpass);