var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var mySchema = new Schema({

    UserName: String,
    Email: String,
    Password: String,
    Role: String,
    Bio: String,
    Interests: String,
    Image: String,
    Salt: String
});
module.exports = mongoose.model('logger', mySchema);
