var express= require('express');
var path= require('path');
var http= require('http');
var bodyParser= require('body-parser');
var socket= require('socket.io'); //
//var passport=require('passport');// helps in auth need to learn later
//var session=require('express-session'); //need to learn later

var mongoose=require('mongoose');


var routes= require('./routes/index');
var users= require('./routes/users');
var adminPage=require('./routes/adminPage');


var app= express();


//to set for views
app.set('views', path.join(__dirname, 'views')); //didn't understand
app.set('view engine', 'ejs'); 

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended:false}));  // to parse form elements
//app.use(express.methodOverride());

app.use('/',routes);
app.use('/users',users);
app.use('/adminPage',adminPage);

//app.use(session());
//app.use(passport.initialize());
//app.use(passport.session());

//mongo element

mongoose.connect('mongodb://127.0.0.1:27017/myDB'); // new line

var employee= require('./DBase/dataBase');
var loggedUser=[];

// Action from Index
app.post('/normalUser', function(req,res){  ///display to /normalUser

//console.log('/display');
console.log(req.body.username);
var query = {};
query['_id'] = req.body.username;
query['pass']= req.body.password; 
if(req.body.username!=null){
 employee.findOne(query, function(err,docs){
     
     console.log(docs);
     if(err) res.json(err);
     else if(docs != null) {
         console.log('docs not null');
         if(docs.role == "admin") {
             console.log('Admin');
             res.render('adminPage');
         }
         else
         {
             console.log('Not Admin');
            loggedUser=req.body.username;
            employee.update({'_id': docs.id}, {$set: {'active': 'y'}}, {upsert:true}, function(err, updateddata){   // upsert helps in modifing that row doesnot create a new row
                if(err){
                    console.log(err);
                }
                else
                {
                    console.log(updateddata);
                }
            });
             res.render('normalUser',{user: loggedUser} );
             
             io.sockets.on('connection', function(client){ //
            console.log("Connected:" +loggedUser);
            client.emit('messages', {hello : 'world' });// yeh ab nahi aa raha hai

          });
         }
     }
     else
     {    
         console.log('user not found');
         var msg= "User not found, Please Sign Up or Enter the required fields";
             res.render('index',{msg: msg});    
     } 
 }); }
});

// Action from userDetails
app.post('/test', function(req,res){  // Control from userDetails
   if(req.body.eId!=null){
    new employee({
       _id: req.body.eId,
       role: "user",
       fname: req.body.fname,
       lname: req.body.lname,
       pass: req.body.password,
       active: "n"
   }).save(function(err, doc){
         if(err) res.json(err);
         else {  
             var msg= "Account Created Email ID is your Username";
             res.render('index',{msg: msg});
         }
   });    }
});

app.post('/adminTest', function(req,res){  // Control from userDetails
   if(req.body.eId!=null){
    new employee({
       _id: req.body.eId,
       role: "user",
       fname: req.body.fname,
       lname: req.body.lname,
       pass: req.body.password,
       active: "n"
   }).save(function(err, doc){
      if(err) res.json(err);
      else {  
        var msg= "Account Created Email ID is your Username";
        res.render('adminPage',{msg: msg});
      }
   });  }
});

app.post('/userEntry', function(req,res){
  res.render('adminCreateUser');
  });


//Logout Action from normalUser

app.post('/logout', function(req,res){    //Problamatic we don't need display here.
var query={};
 query["_id"]=req.body.eid;
 console.log(req.body.eId);

 employee.findOne(query, function(err,docs){
    employee.update({'_id': docs.id}, {$set: {'active': 'n'}}, {upsert:true}, function(err, updateddata){   // upsert helps in modifing that row doesnot create a new row
              if(err){
                console.log(err);
              }
              else
              {
                var msg= "You have successfully logged out";
                res.render('index',{msg: msg});
              }
            });
      });
});

//Action for Active users from adminPage
app.post('/activeUsers', function(req,res){
 var query={};
 query["active"]="y";
 employee.find(query, function(err,docs){
    res.render("activeDisplay", {user: docs});
 });
});

//Action for Deactive users from adminPage
app.post('/deactiveUsers', function(req,res){
 var query={};
 query["active"]="n";
 employee.find(query, function(err,docs){
    res.render("display", {user: docs});
 });
});

app.post('/deletedUsers', function(req,res){
 var query={};
 query["active"]="d";
 employee.find(query, function(err,docs){
    res.render("deletedUsers", {user: docs});
 });
});

app.post('/Delete', function(req,res){   //For Active Users
 var query={};
 query["_id"]=req.body.eId;
 console.log(req.body.eId);

 employee.findOne(query, function(err,docs){
    employee.update({'_id': docs.id}, {$set: {'active': 'd'}}, {upsert:true}, function(err, updateddata){   // upsert helps in modifing that row doesnot create a new row
              if(err){
                console.log(err);
              }
              else
              {
                //console.log(updateddata);
                
                var query={};
                query["active"]="y";
                employee.find(query, function(err,docs){
                res.render("activeDisplay", {user: docs});
                });
               
              }
            });
      });
});

//Deleted Users
app.post('/deactiveDelete', function(req,res){   //For Active Users
 var query={};
 query["_id"]=req.body.eId;
 console.log(req.body.eId);

 employee.findOne(query, function(err,docs){
    employee.update({'_id': docs.id}, {$set: {'active': 'd'}}, {upsert:true}, function(err, updateddata){   // upsert helps in modifing that row doesnot create a new row
              if(err){
                console.log(err);
              }
              else
              {
                //console.log(updateddata);
                
                var query={};
                query["active"]="y";
                employee.find(query, function(err,docs){
                res.render("display", {user: docs});
                });
               
              }
            });
      });
});

app.post('/makeActive', function(req,res){ // For DeActive Users
 var query={};
 query["_id"]=req.body.eid;
 console.log(req.body.eid);
 employee.findOne(query, function(err,docs){
    employee.update({'_id': docs.id}, {$set: {'active': 'y'}}, {upsert:true}, function(err, updateddata){   // upsert helps in modifing that row doesnot create a new row
              if(err){
                console.log(err);
              }
              else
              {
                //console.log(updateddata);
                
                var query={};
                query["active"]="n";
                employee.find(query, function(err,docs){
                res.render("display", {user: docs});
                });
               
              }
            });
      });
});

app.post('/makeDeletedActive', function(req,res){ // For Deleted Users
 var query={};
 query["_id"]=req.body.eid;
 console.log(req.body.eid);
 employee.findOne(query, function(err,docs){
    employee.update({'_id': docs.id}, {$set: {'active': 'y'}}, {upsert:true}, function(err, updateddata){   // upsert helps in modifing that row doesnot create a new row
              if(err){
                console.log(err);
              }
              else
              {
                //console.log(updateddata);
                
                var query={};
                query["active"]="d";
                employee.find(query, function(err,docs){
                res.render("deletedUsers", {user: docs});
                });
               
              }
            });
      });
});



server.listen(8081, function(){
    console.log("Listening to port 8081");
});
//to get users connected to internet
/*io.sockets.on('connection', function(client){ //
    console.log("BAndey aa gaye hai");
    client.emit('messages', {hello : 'world' });// yeh ab nahi aa raha hai
});*/


module.exports=app;
module.exports=server;
